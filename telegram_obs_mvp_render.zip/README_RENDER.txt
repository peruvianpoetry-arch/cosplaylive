Telegram OBS MVP (Render Ready)
1. Go to https://render.com
2. New → Web Service → Upload ZIP.
3. Add env vars:
   TELEGRAM_BOT_TOKEN
   TELEGRAM_CHAT_ID
   TRANSLATE_TO=de
   ENABLE_TRANSLATION=1
4. Render auto starts the bot (python app.py)
